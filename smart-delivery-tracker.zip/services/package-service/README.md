# Package Service

This is the Package Service for the Smart Delivery Tracker.

### Endpoints:
- GET /health
- GET /package/<id>
