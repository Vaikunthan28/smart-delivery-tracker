# Smart Delivery Tracker

Microservices-based project to track deliveries with CI/CD, Kubernetes, and EKS.
